# Restoran Table Service

JARESTO merupakan sebuah aplikasi restoran berbasis web yang bertujuan untuk memudahkan pelanggan dan user lainnya dalam memesan
orderannya. Aplikasi ini terdiri dari 6 user yaitu admin, waiter, kasir, owner, pelanggan dan koki.

## Login Pelanggan
<p align="center">
  <img src="https://user-images.githubusercontent.com/33746018/56844322-c773f200-68d8-11e9-920b-60276f60b6ae.PNG" align="middle" />
</p>

## Dashboard Admin
<p align="center">
  <img src="https://user-images.githubusercontent.com/33746018/56844322-c773f200-68d8-11e9-920b-60276f60b6ae.PNG" align="middle" />
</p>

## Kategori Makanan Admin
<p align="center">
  <img src="https://user-images.githubusercontent.com/33746018/56844361-6ac50700-68d9-11e9-9d0d-b6a7f8269c63.PNG" align="middle" />
</p>

## Laporan Transaksi Admin
<p align="center">
  <img src="https://user-images.githubusercontent.com/33746018/56844362-6b5d9d80-68d9-11e9-9af4-f38b7412a800.PNG" align="middle" />
</p>

## Input Meja
<p align="center">
  <img src="https://user-images.githubusercontent.com/33746018/56844363-6b5d9d80-68d9-11e9-919d-152870c3ca9c.PNG" align="middle" />
</p>

## Transaksi
<p align="center">
  <img src="https://user-images.githubusercontent.com/33746018/56844395-cabbad80-68d9-11e9-9f9f-f3e1b4999c2e.PNG" align="middle" />
</p>
